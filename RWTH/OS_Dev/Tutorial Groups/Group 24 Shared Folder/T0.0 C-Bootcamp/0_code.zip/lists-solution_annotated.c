#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct stud_type {
    int id;
    char firstname[20];
    char lastname[20];
    struct stud_type *next;
} stud_type;


/* Is the database empty? */
bool is_empty(stud_type const* list) {
    return !list;
}

/* Helper function to create a student
 * 
 */
static stud_type* create_student(int matnum, char const vorname[20], char const nachname[20]) {
    //Speicherplatz für neuen Studenten zuweisen
    stud_type* student = malloc(sizeof(*student));
    //Fehlschläge abfangen
    if(!student) {
        return NULL;
    }
    //Attribute setzen: (->) für Zugriff auf die Attribute des structs
    student->id = matnum;
    //Methode strncpy(destination, source, n) kopiert die ersten n Bytes von source nach destination
    strncpy(student->firstname, vorname, sizeof(student->firstname) - 1);
    // '\0' zeigt, dass der String vorbei ist
    student->firstname[sizeof(student->firstname) - 1] = '\0';
    strncpy(student->lastname, nachname, sizeof(student->lastname) - 1);
    student->lastname[sizeof(student->lastname) - 1] = '\0';

    return student;
}

/* Insert an element
 * 
 * Gets a pointer to a pointer, which points to the 1. element of the list
 * Gets ID, first name and last name of the student to be inserted
 *
 * Returns true if successful
 * Returns false to indicate an error
 */
bool enqueue(stud_type** students_list, int id, char const firstname[20], char const lastname[20]) {

    //Verkettete Liste solange durchsuchen, bis wir eine ID finden, die größer als die einzufügende ID ist
    stud_type* prev = NULL;
    stud_type* curr = *students_list;
    while(curr && curr->id < id) {
        prev = curr;
        curr = curr->next;
    }
    //Falls die ID des zuletztbetrachteten Studis gleich der einzufügenden ID ist, müssen wir eine andere ID für unseren neuen Studi nehmen und geben false zurück
    if(curr && curr->id == id) {
        return false;
    }

    //Neuer Studi muss erstellt werden - in Hilfsmethode oben ausgelagert
    stud_type* student = create_student(id, firstname, lastname);
    //Prüfe, ob das Erstellen des neuen Studis erfolgreich war
    if(!student) {
        return false;
    }

    //Setze next-Zeiger vom neuen Studi auf den Studi, der bisher ursprünglich an dieser Stelle stand 
    student->next = curr;
    //Falls es einen Vorgänger gab, setze den next-Zeiger des Vorgängers auf den neu erstellten Studi
    if(prev) {
        prev->next = student;
    //Falls es keinen Vorgänger gibt, setze den Startzeiger des structs auf den neuen Studi
    } else {
        *students_list = student;
    }

    return true;
}

/* Remove an element
 * 
 * Gets a pointer to a pointer, which points to the 1. element of the list
 * Gets the ID of the student to be deleted
 *
 * Returns true if successful
 * Returns false to indicate an error
 */
bool dequeue(stud_type** students_list, int id) {
    /* Prüfe Randbedingungen */
    if(is_empty(*students_list)) {
        return false;
    }

    //Dursuche die Datenbank analog zu oben
    stud_type* prev = NULL;
    stud_type* curr = *students_list;
    while(curr && curr->id < id) {
        prev = curr;
        curr = curr->next;
    }
    //Falls wir keinen Studi mit der gesuchten ID finden, gebe false zurück
    if(!curr || curr->id != id) {
        return false;
    }
    
    //Speichere den Nachfolger von dem zu löschenden Studi zwischen
    stud_type* next = curr->next;
    //Speicherplatz freigeben
    free(curr);
    
    //Falls ein Vorgänger existiert, setze dessen next-Zeiger auf den zwischengespeicherten Nachfolger vom gelöschten Studi
    if(prev) {
        prev->next = next;
    //Falls es keinen Vorgänger gibt, setze den Startzeiger des structs auf den zwischengespeicherten Nachfolger vom gelöschten Studi
    } else {
        *students_list = next;
    }

    return true;
}

/* Read an element 
 *
 * Gets a pointer to the list type
 * Gets the ID of the student whose data is to be read
 *
 * Writes first and last name into firstname and lastname, respectively
 */
bool get_student(stud_type const* students_list, int id, char firstname[20], char lastname[20]) {
    //Durchsuche die Datenbank wieder
    stud_type const* curr = students_list;
    while (curr && curr->id < id) {
        curr = curr->next;
    }
    //Falls wir keinen Studi mit der gesuchten ID finden, gebe false zurück
    if (!curr || curr->id != id) {
        return false;
    //sonst: kopiere Daten in die übergebenen Strings
    } else {
        //Methode strncpy(destination, source, n) kopiert die ersten n Bytes von source nach destination
        strncpy(firstname, curr->firstname, 19);
        // '\0' zeigt, dass der String vorbei ist
        firstname[19] = '\0';
        strncpy(lastname, curr->lastname, 19);
        lastname[19] = '\0';

        /* Return value: OK */
        return true;
    }
}

/* Exercise 2.1.a)
 * Helper function that frees the memory used by the new lists
 */
void free_stud_type(stud_type** liste) {
    for(stud_type* curr = *liste; curr; ) {
        stud_type* next = curr->next;
        free(curr);
        curr = next;
    }
}



/* Exercise 2.1.b)
 * Struct analogous tu stud_type to
 *
 * i) reference the student struct (stud_type) in the original list
 * ii) reference the new struct in the new list (stud_ind_t)
 */
typedef struct stud_ind_t {
    stud_type* student;
    struct stud_ind_t* next;
} stud_ind_t;
typedef int (*stud_cmp_t)(stud_type const* a, stud_type const* b);

int cmp_firstname(stud_type const* a, stud_type const* b) {
    //Methode strncmp(s1,s2,n) vergleicht die ersten n Bytes alphabetisch - Rückgabe: 0 für equal, negative value für s1 < s2, positive value für s1 > s2
    return strncmp(a->firstname, b->firstname, sizeof(a->firstname));
}

int cmp_lastname(stud_type const* a, stud_type const* b) {
    //siehe oben
    return strncmp(a->lastname, b->lastname, sizeof(a->lastname));
}

/* Exercise 2.1.b)
 * Helper function that frees the memory used by the new lists
 */
void free_stud_ind(stud_ind_t** liste) {
    for(stud_ind_t* curr = *liste; curr; ) {
        stud_ind_t* next = curr->next;
        free(curr);
        curr = next;
    }
}

/* Exercise 2.1.b)
 * Function that sorts the original stud_type list using the comparison function
 */
stud_ind_t* sort_students(stud_type* students, stud_cmp_t stud_cmp) {
    //Randfälle beachten
    if(is_empty(students)) {
        return NULL;
    }
    //Erstelle neue Liste für alphabetische Reihenfolge
    stud_ind_t* liste = malloc(sizeof(*liste));
    liste->student = students;
    liste->next = NULL;

    //iteriere über die existierende Liste
    for(stud_type* curr_stud = students->next; curr_stud; curr_stud = curr_stud->next) {
        //erstelle einen neuen Studi als stud_ind_t objekt und weise Speicher zu
        stud_ind_t* new = malloc(sizeof(*new));
        //Fehler beim Speicher zuweisen abgfangen und ggf. Liste leeren
        if(!new) {
            free_stud_ind(&liste);
            return NULL;
        }
        //Attribute zuweisen
        new->student = curr_stud;
        stud_ind_t* prev_ind = NULL;
        stud_ind_t* curr_ind = liste;

        /* Go through the new list until the insertion point for curr_stuf is found */
        while(curr_ind && (*stud_cmp)(curr_ind->student, curr_stud) <= 0) {
            prev_ind = curr_ind;
            curr_ind = curr_ind->next;
        }
        new->next = curr_ind;
        //Tausche Zeiger (von oben bekannt()
        if(prev_ind) {
            prev_ind->next = new;
        } else {
            liste = new;
        }
    }
    return liste;
}

//Ab hier Testmethoden und Beispielausführung

static void test_empty(stud_type const* list) {
    printf(">>> Testing whether the student list is empty ...\n");

    if(is_empty(list)) {
        printf("    The student list is empty \n");
    } else {
        printf("    The student list is not empty \n");
    }
}

static void test_get(stud_type const* list, int id) {
    printf(">>> Testing, whether the ID %4i exists ...\n", id);

    char firstname[20];
    char lastname[20];
    if(get_student(list, id, firstname, lastname)) {
        printf("    ID %4i: %s %s\n", id, firstname, lastname);
    } else {
        printf("    ID %4i is not known\n", id);
    }
}

static void test_enqueue(stud_type** list, int id, char const* firstname, char const* lastname) {
    printf(">>> Inserting the new student into the list: %s %s [%4i] ...\n", firstname, lastname, id);
    if(enqueue(list, id, firstname, lastname)) {
        printf("    ID %4i inserted\n", id);
    } else {
        printf("    ID %4i couldn't be inserted\n", id);
    }
}

static void test_dequeue(stud_type** list, int id) {
    printf(">>> Removing ID %4i ...\n", id);

    if(dequeue(list, id)) {
        printf("    ID %4i removed\n", id);
    } else {
        printf("    ID %4i is not known\n", id);
    }
}

static void test_dump(stud_type const* list) {
    printf(">>> Printing all known students ...\n");
    for(stud_type const* curr = list; curr; curr = curr->next) {
        printf("    ID %4i: %s %s\n", curr->id, curr->firstname, curr->lastname);
    }
}

/* Test all the list functions  */
int main(void) {
    /* Initialize database */
    stud_type* studens_list = NULL;

    test_empty(studens_list);
    test_enqueue(&studens_list, 1234, "Eddard", "Stark");
    test_get(studens_list, 1234);
    test_enqueue(&studens_list, 5678, "Jon", "Snow");
    test_get(studens_list, 1234);
    test_enqueue(&studens_list, 9999, "Tyrion", "Lannister");
    test_get(studens_list, 1235);
    test_enqueue(&studens_list, 1289, "Daenerys", "Targaryen");
    test_dequeue(&studens_list, 1234);
    test_empty(studens_list);
    test_get(studens_list, 5678);
    test_dequeue(&studens_list, 9998);
    test_enqueue(&studens_list, 1289, "Viserys", "Targaryen");
    test_dequeue(&studens_list, 5678);
    test_enqueue(&studens_list, 1, "Tywin", "Lannister");
    test_dump(studens_list);

    {
        /* Generate list sorted by first name */
        stud_ind_t* liste = sort_students(studens_list, &cmp_firstname);
        /* Print list */
        printf(">>> Printing all known students ...\n");
        for(stud_ind_t* curr = liste; curr; curr = curr->next) {
            printf("    ID %4i: %s %s\n", curr->student->id, curr->student->firstname, curr->student->lastname);
        }
        /* Delete list */
        free_stud_ind(&liste);
    }

    {
        /* Erzeuge sortierte Liste nach Nachname */
        stud_ind_t* liste = sort_students(studens_list, &cmp_lastname);
        /* Print list */
        printf(">>> Printing all known students ...\n");
        for(stud_ind_t* curr = liste; curr; curr = curr->next) {
            printf("    ID %4i: %s %s\n", curr->student->id, curr->student->firstname, curr->student->lastname);
        }
        /* Delete list */
        free_stud_ind(&liste);
    }
    free_stud_type(&studens_list);
    return 0;
}
