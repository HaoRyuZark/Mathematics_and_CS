#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* Definition of useful constants */
/* Maximal length of the codeword */
#define MAXCODE 10

/* Maximal length of the text/cipher */
#define MAXTEXT 100

/* Operation CODE = encrypt, DECODE = decrypt */
#define CODE    0
#define DECODE  1

/* This reads from the keyboard "length", which is the number
 off character it saved it in the variable txt. */
void readFromKeyboard(char *txt, int length)
{
    int count = 0;
    int c;
    
    /* Reading the first character outside of the loop,
    so that the loop condition can be evaluated. */
     
    c = getchar();
    
    /* As long as the entered character is not "end of line",
     read from the keyboard, but a maximum of "length" characters. */
    while(count<length && c!='\n') {
        txt[count] = c;
        count++;
        c = getchar();
    }
    /* End the array with a "\0", so that other functions can see
     where the String ends. */
    txt[count] = '\0';
}

/* This function reads a codeword from the keyboard 
 and saves in the variable txt. */
void readCodeword(char *txt) {
    printf("Enter a codeword <= %d charaacters:", MAXCODE);
    readFromKeyboard(txt, MAXCODE);
}

/* This function reads the ciphertext/plaintext from the keyboard 
 and saves in the variable txt. */
void readPlaintext(char *txt) {
    printf("Enter a plaintext or ciphertext <= %d characters:", MAXTEXT);
    readFromKeyboard(txt, MAXTEXT);
}

/*This function asks the user, whether we should encrypt or decrypt. */
int readOperation() {
    char operation;
    
    printf("Enter (e) to encrypt and (d) to decrypt:");
    scanf("%c", &operation);
    if( operation == 'e')
        return CODE;
    else
        return DECODE;
}


/* This procedure prepares the text passed in the variable "text", 
i.e., all lowercase letters are converted to uppercase and special characters are removed. 
The cleaned text is stored in the variable "clean", 
this contains only uppercase letters and numbers. 
Used functions: 
- isalnum: Checks if the specified character is a letter or a number. 
- islower: Checks if the specified character is a lowercase letter. */

void prepareText(char *text, char *clean)
{
    /* Counter for the original text */
    int i;
    /* Counter for the processed text.*/
    int n = 0;
    
    /* Every character from "text" will be converted one by one. */
    for(i=0; i < (int)strlen(text); i++) {
        
        /* Only letters and numbers will be considered in the converting. */
        if(isalnum(text[i])) {
            /* Only conver non capital letters. */
            if(islower(text[i]))
                clean[n] = text[i] + 'A' - 'a';
            else
                clean[n] = text[i];
            n++;
        }
    }
    
    /* End the new "String" with a null "\0", so that other functions can find the end. */
    clean[n] = '\0';
}

/* This computes the coding to an allowed character "plain". The result is in the range 0 - 36. */

int computeCode(char plain) {
    if((plain>='A') && (plain<='Z'))
        return plain - 'A';
    else
        if(isdigit(plain))
            return 26 + plain - '0';
    return plain;
}
/* This function computes the characters to code */
char computeCharacters(int code) {
    if((code>=0) && (code<=25))
        return 'A' + code;
    else
        if((code>=26) && (code<=35))
            return '0' + code - 26;
    return code;
}


/* This function encrypts/decrypts the "plaintext" with the codeword "codeword" 
based on the value of the paraneter "operation" and saves in the result variable "result". */
void coding(char *codeword, char *plaintext, char *result, int operation)
{
    /* Definition of used variables */
    int i;
    int codeText;
    int codeCode;
    int codeResult;
    int codeLength;
    
    codeLength = strlen(codeword);
    printf("Coding:\n");
    /* In the loop the "plaintext" characters will be encrypted or decrypted. */
    for(i=0; i < (int)strlen(plaintext); i++) {

        /*Calculate the coding for the characters of the codeword and the plaintext.*/
        codeText = computeCode(plaintext[i]);
        codeCode = computeCode(codeword[i%codeLength ]);
        /* Encrypt or decrypt based on the value of "operation" */
        if(operation == CODE)
            codeResult = (codeText + codeCode)%36;
        else {
            codeResult = (codeText - codeCode)%36;
            /* During decoding, it can happen that the result becomes negative, 
            then owe must add 36 to correct the modulo calculation. */
            if(codeResult < 0)
                codeResult += 36;
        }
        result[i] = computeCharacters(codeResult);
    }
    
    /* End the new "String" with a null "\0", so that other functions can find the end. */
    result[i+1] = '\0';
}

int main() {
    /* Defining our used variables*/
    
    /* Codeword*/
    char codeword[MAXCODE+1];
    /* Codeword after preparation*/
    char cleancodeword[MAXCODE+1];
    /* Text/cipher */
    char plaintext[MAXTEXT+1];
    /* Text/cipher after preparation  */
    char cleanPlaintext[MAXTEXT+1];
    /* Result of encryption/decryption */
    char result[MAXTEXT+1];
    /* Decides whether to encrypt or decrypt */
    int  operation;
    
    /* Read the codeword */
    readCodeword(codeword);
    
    /* Read text or cipher*/
    readPlaintext(plaintext);
    
    /* Read the operation to be executed */
    operation = readOperation();
    
    /* Prepare the text and the code for encryption */
    prepareText(plaintext, cleanPlaintext);
    prepareText(codeword, cleancodeword);
    
    /* Execute encryption/decryption */
    coding(cleancodeword, cleanPlaintext, result, operation);
    
    /* Output the result */
    printf("Result:\n");
    printf("Codeword: %s\n", codeword);
    printf("Clean text: %s\n", cleanPlaintext);
    printf("Clean codeword: %s\n", cleancodeword);
    printf("------------------------------------------\n");
    printf("Result: %s\n", result);
    
    return 0;
}
