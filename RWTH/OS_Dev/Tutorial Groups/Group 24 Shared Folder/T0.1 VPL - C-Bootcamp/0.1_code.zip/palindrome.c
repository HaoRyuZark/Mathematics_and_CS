#include <stdbool.h>
#include <stdio.h>

/* 
write a function that check whether 
the given string is a palindrome or not

additionnal functions can be written to help you with this task
*/
char *last_character(char *string) {
    char *end = string;
    //finde das Ende von string: nutze die Besonderheit, dass alle Strings mit '\0' enden
    while (*(end + 1) != '\0') {
        end++;
    }
    
    return end;
}

bool palindrome(char *string) {
    char *start = string;
    char *end = last_character(string);
    
    //vergleiche ersten mit letztem Buchstaben, zweitem mit vorletztem, usw.
    while (start < end) {
        if (*start != *end) {
            return false;
        }
        start++;
        end--;
    }
    
    return true;
}

//nur für Demonstrationszwecke, darf nicht ins VPL kopiert werden (main-Methode ist schon vorgegeben)
int main(void) {
    printf("OTTO: %i\n", palindrome("OTTO"));
    printf("BANANE: %i\n", palindrome("BANANE"));
    printf("abcdeffedcba: %i\n", palindrome("abcdeffedcba"));
}