#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include "prime.h"

/* return true if n is prime, false otherwise */
bool is_prime(long a) {
  //Randfälle abdecken
  if (a == 1) {
    return false;
  }
  if (a == 2 ) {
    return true;
  }
  //Check, ob durch 2 teilbar, um unnötige Schleifendurchläufe zu vermeiden
  if (a % 2 == 0) {
    return false;
  }
  //Primzahltest für alle größeren Zahlen
  for (int i = 3; i < a; i+=2) {
    if (a % i == 0) {
      return false;
    }
  }
  
  return true;
}

/* return the nth prime number */
long nth_prime(int n) {
	long prime = 1;
	//erste prime
  if (n-- == 1) {
    return 2;
  }
  //finde nächste prime
	while (n) {
    prime += 2;
    if (is_prime(prime)) {
      n--;
    }
  }
  
	return prime;
}

//nur für Demonstrationszwecke, darf nicht ins VPL kopiert werden (main-Methode ist schon vorgegeben)
int main(void) {
    int n;
    printf("n is prime? = ");
    scanf("%d", &n);
    printf("%d\n", is_prime((long) n));
    printf("nth prime? = ");
    scanf("%d", &n);
    printf("%d\n", nth_prime((long) n));
}