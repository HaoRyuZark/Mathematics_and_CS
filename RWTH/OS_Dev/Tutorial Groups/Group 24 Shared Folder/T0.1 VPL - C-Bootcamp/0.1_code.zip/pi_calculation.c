#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include "pi_calculation.h"

/* fill the structure with random values between -1 and 1 */
/* the definition of the structure is located in the pi_calculation.h */
void random_coordinates(struct coordinates *coords) {
    coords->x = -1.0 + ((double) rand() / ( (double) RAND_MAX / 2.0));
    coords->y = -1.0 + ((double) rand() / ( (double) RAND_MAX / 2.0));
}

//helper function
double square(double a) {
    return a*a;
}

/* return true if the point given in argument is inside the circle 
of center (0,0) and radius 1” */
bool is_inside_circle(struct coordinates *coords) {
    //nutze Satz des Pythagoras
    return (square(coords->x) + square(coords->y) < 1);
}

/* 
returns the pi calculation approximation after n iterations,
the monte carlo method for pi calculation works as follow:
    - draw n random points with their coordinates between -1 and  1 (you should use your random_coordinates function)
    - calculte the ratio of points inside the circle over the total number of points
    - multiply the ratio by 4 and return this value
*/
double monte_carlo_method(double n) {
    int i;
    int count = 0;

    //for rand()
    srand(time(NULL));

    for (i = 0; i < n; i++) {
        struct coordinates *coords = malloc(sizeof(*coords));
        //Fehlschläge abfangen
        if(!coords) {
            return 0.;
        }
        //erstelle random Koordinaten und schaue ob sie im Kreis liegen
        random_coordinates(coords);
        if (is_inside_circle(coords)) {
            count++;    
        }

        free(coords);
    }
    //teile Punkte innerhalb des Kreises durch Gesamtanzahl der Punkte (s. Skizze)
    double ratio = (double) count / n;
    // pi/4 * 4 = pi (s. Skizze)
    double pi = ratio * 4;

    return pi;
}

//nur für Demonstrationszwecke, darf nicht ins VPL kopiert werden (main-Methode ist schon vorgegeben)
int main(void) {
    int n;
    printf("n = ");
    scanf("%d", &n);
    printf("%f\n", monte_carlo_method((double) n));
}