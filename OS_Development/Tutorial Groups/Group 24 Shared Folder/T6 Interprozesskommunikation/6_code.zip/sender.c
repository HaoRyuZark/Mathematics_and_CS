#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define BUFFER_SIZE 256

int main () {
    char mypipe [] = "/tmp/mypipe";
    if (mkfifo(mypipe , S_IRUSR | S_IWUSR) == -1) {     //Erstellen der Pipe
        perror("mkfifo");
        exit (1);
    }
    int fd_send = open(mypipe , O_WRONLY);  //Öffnen der Pipe
    if (fd_send == -1) {
        perror("open");
        exit (1);
    }
    char buffer_send[BUFFER_SIZE];
    do {
        fgets(buffer_send , BUFFER_SIZE , stdin);
        if (write(fd_send , buffer_send , strlen(buffer_send)+1) == -1){
            perror("write");
            exit (1);
        }
    } while (strcmp(buffer_send , "exit")); //Schreiben in die Pipe
    if (remove(mypipe) == -1) {     //Entfernen der Pipe
        perror("remove");
        exit (1);
    }
    if (close(fd_send) == -1) {     //Senderdatei muss geschlossen werden
        perror("close");
        exit (1);
    }
    return 0;
}