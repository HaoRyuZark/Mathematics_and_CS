#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define BUFFER_SIZE 256

int main () {
    char mypipe [] = "/tmp/mypipe";
    int fd_recv = open(mypipe , O_RDONLY);  //Öffnen von der Pipe
    if (fd_recv == -1) {
        perror("open");
        exit (1);
    }
    char buffer_recv[BUFFER_SIZE];
    do {
        if (read(fd_recv , buffer_recv , sizeof(buffer_recv)) == -1) {
            perror("read");
            exit (1);
        }
        printf("> %s", buffer_recv);
    } while (strcmp(buffer_recv , "exit\n"));

    if (close(fd_recv) == -1){      //Filedeskriptor
        perror("close");
        exit (1);
    }
    return 0;
}
