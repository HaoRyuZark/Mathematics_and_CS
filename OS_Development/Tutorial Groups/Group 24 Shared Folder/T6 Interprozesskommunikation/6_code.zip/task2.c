#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

struct Stack {
  int idx;
  int size;
  sem_t sem_free;
  sem_t sem_used;
  sem_t mutex;
  int *stack;
};

struct Stack *init_stack(int size) {
  struct Stack *stack = mmap(NULL, sizeof(struct Stack), PROT_READ | PROT_WRITE,
                             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  int *stack_t = mmap(NULL, sizeof(int) * size, PROT_READ | PROT_WRITE,
                      MAP_SHARED | MAP_ANONYMOUS, -1, 0);

  if (!stack || !stack_t) {
    perror("mmap");
    exit(1);
  }

  stack->idx = 0;
  stack->size = size;
  sem_init(&stack->sem_free, 1, size);
  sem_init(&stack->sem_used, 1, 0);
  sem_init(&stack->mutex, 1, 1);

  stack->stack = stack_t;
  return stack;
}

int shared_pop(struct Stack *stack) {
  sem_wait(&stack->sem_used);   //sem_used --

  sem_wait(&stack->mutex);      //Mutex beansprucht
  int ret = stack->stack[--stack->idx];   //Oberstes Element wird gespeichert und "vom Stapel geworfen"
  sem_post(&stack->mutex);      //Mutex freigeben

  sem_post(&stack->sem_free);   //sem_free ++
  return ret;                   //oberstes Element zurückgeben
}

void shared_push(struct Stack *stack, int value) {
  sem_wait(&stack->sem_free);         //sem_free --

  sem_wait(&stack->mutex);            //Mutex beanspruchen
  stack->stack[stack->idx++] = value; //Übergebene Element wird an den obersten Index gelegt
  sem_post(&stack->mutex);            //Mutex freigeben

  sem_post(&stack->sem_used);         //sem_used ++
}

int main() {
  srand(time(NULL));

  struct Stack *stk = init_stack(200);

  for (int i = 0; i < 10; i++) {
    if (fork() == 0) {
      while (1) {
        shared_push(stk, rand() % 20);
      }
    }
  }

  for (int i = 0; i < 10; i++) {
    if (fork() == 0) {
      while (1) {
        shared_pop(stk);
      }
    }
  }

  wait(NULL);
}
