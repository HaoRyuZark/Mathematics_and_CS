#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* 
Schreibe ein C-Programm, dass einen fork() ausführt.
Der child-Prozess soll einen ls-command ausführen (mit execl())
Währenddessen wartet der parent-Prozess auf das Kind und printet eine completion-Message

int execl (const char *pathname, const char *arg, ...);
  Ersetzt das aktuelle Programm mit dem als Parameter übergebenen Programm
  Return: -1 bei Error, sonst kein Return, aber Start des neuen Programms

pid_t wait(int *status);
  Warte darauf, dass jeder Kindprozess sich beendet oder eine Statusänderung bekommt
  Return: PID vom Kind, -1 bei Fehler

Der execl-call wird so benutzt: 
  int ret = execl("/bin/ls", "ls", "/", NULL);
*/

int main() {
  //Speichere PID vom fork
  pid_t pid = fork();

  //Wieder Fallunterscheidung: -1 = Fehler, 0 = im Kindprozess
  if (pid == -1) {
    perror("Fehler bei fork");
  } else if (pid == 0) {
    //im Kindprozess
    if (!execl("/bin/ls", "ls", "/", NULL)) { //vorgegebenen Befehl nutzen & Fehler abfangen
      perror("Fehler execl");   
    }
  }
  //Diesen Teil führt das Kind nicht mehr aus, da sein Programm durch execl ersetzt wurde! (siehe PDF Seite 14)
  //Elternprozess soll auf Kind warten und dann Completion printen
  wait(&pid);
  printf("\nChild exited\n");
}
