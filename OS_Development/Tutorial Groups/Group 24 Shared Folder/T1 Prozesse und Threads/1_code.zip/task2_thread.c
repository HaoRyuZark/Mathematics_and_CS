#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
/*
Nun sollen wir das fork-Programm von eben mit Threads umsetzen
Dazu nutzen wir pthread_create, pthread_exit und pthread_join
*/

/*
Wichtige Methoden für Threads:

int pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*function)(void *), void *arg);
  Erzeuge einen neuen Thread mit Attributen attr (default wenn NULL)
  Return: Thread_ID, bei Fehler -1
Parametererklärung:
  1. pthread_t *thread: Pointer zur ThreadID, die dann angepasst wird
  2. const pthread_attr_t *attr: Attribute, die die Eigenschaften des Threads bestimmen. Falls NULL, werden default Attribute verwendet
  3. void *(*function)(void *): Funktion, die beim Start des Threads aufgerufen wird
  4. void *arg: Argumente, die dem Thread übergeben werden

void pthread_exit(void *retval);
  Beendet den aufgerufenen Thread

int pthread_join(pthread_t thread, void **retval);
  Darauf warten, dass der übergebene Thread beendet wird
*/

int global_variable = 0;

void *thread_routine(void *args) {
  //args ist die ThreadID vom aktuellen Thread, soll für die Ausgabe zwischengespeichert werden
  pthread_t current = (pthread_t) args;

  pthread_t thread_id[5];

  int nb_childs = 0;

  /*Unser Loop bis 5, mit global_variable++ können wir direkt inkrementieren NACHDEM der Vergleich stattgefunden hat 
  (++global_variable < 5 würde erst die Variable erhöhen und dann vergleichen)*/ 
  while (global_variable++ < 5) {
    printf("Thread %lu, Globale Variable = %d \n", current, global_variable);

    //Erzeugung vom neuen Thread mit neuem Aufruf dieser Routine
    pthread_create(&thread_id[nb_childs], NULL, thread_routine, &thread_id[nb_childs]);
    /* Parametererklärung:
        - &thread_id[nb_childs]: Adresse, wo unsere ThreadID gespeichert wird
        - NULL, nur default Attribute werden verwendet
        - thread_routine: diese Methode wird auch vom neuen Thread aufgerufen
        - &thread_id[nb_childs]: als Parameter für die Routine wird die ThreadID vom erzeugten Thread übergeben
    */

    //wird erhöht für neuen Thread
    nb_childs++;
  }

  //for-Schleife, damit gewartet wird, bis jeder Thread beendet ist
  for (int id = 0; id < nb_childs; id++) {
    pthread_join(thread_id[id], NULL);
  }

  return NULL;
}

int main() {
  long main_thread_id = 0;
  //starte das Programm vom Mainthread aus
  thread_routine(&main_thread_id);
  return 0;
}
/*
Wir sehen, dass wir nur 5 Threads benutzen.
Das liegt daran, dass Threads, im Gegensatz zu Prozessen, Adressräume teilen; jeder Thread hat also Zugriff auf die gleiche global_variable.
Jeder Thread bearbeitet also die gleiche Variable, so dass nur 5 Threads insgesamt erzeugt werden.
(Wegen unzureichender Synchronisation können manchmal auch mehr Threads erzeugt werden, mehr dazu später in der Vorlesung).
*/