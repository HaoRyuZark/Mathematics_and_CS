#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

/*
Schreibe nun das Programm mit Threads statt fork

Der execl-call wird so benutzt: 
  int execl (const char *pathname, const char *arg, ...);
  int ret = execl("/bin/ls", "ls", "/", NULL);
*/

void *routine(void *arg) {
  //analog zum fork-Programm: Vorgegebenen Befehl nutzen und Fehler abfangen
  if (!execl("/bin/ls", "ls", "/", NULL)) {
      perror("Fehler execl");
  }

  return NULL;
}

int main() {
  pthread_t tid;
  
  //Erzeuge einen neuen Thread, der routine ausführt
  pthread_create(&tid, NULL, routine, NULL);  
  /* Parametererklärung: 
      - Adresse auf tid: hier wird dann die ThreadID gespeichert 
      - NULL für default Attribute
      - routine ist oben definiert; führt unseren ls-command aus
      - NULL, da wir keine Argumente übergeben müssen
  */

  //Wir sollen darauf warten, dass der übergebene Thread beendet ist; returnvalue wird nicht benötigt, daher NULL
  pthread_join(tid, NULL);
  printf("\nchild exited\n"); //wird nie aufgerufen, siehe PDF S. 14
}
