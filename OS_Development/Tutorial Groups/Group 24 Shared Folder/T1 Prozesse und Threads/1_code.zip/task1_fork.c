#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
/*
Erstelle eine globale Variable mit Anfangswert 0

In einem Loop wollen wir mit jeder Iteration 
  - die globale Variable erhöhen
  - fork() aufrufen
  - das child soll "Child" mit seiner PID und dem Wert der globalen Variablen printen
  - parent soll "Parent" mit seiner PID und dem Wert der globalen Variablen printen
  - bei globale Variable = 5 sollen wir abbrechen

pid_t fork(void);
  Erzeuge einen neuen Prozess, der ein Duplikat vom aktuellen ist
  Return: im Elternprozess: PID vom Kind, im Kindprozess: 0, bei Fehler: -1

*/

//unsere globale Variable
int global_variable = 0;

int main() {
  //Anlegen einer Variable, damit wir die PID speichern können
  pid_t pid;

  /*Unser Loop bis 5, mit global_variable++ können wir direkt inkrementieren NACHDEM der Vergleich stattgefunden hat 
  (++global_variable < 5 würde erst die Variable erhöhen und dann vergleichen)*/
  while (global_variable++ < 5) {
    //fork gibt uns als Return die PID (Unterscheidung siehe Zeile 17) oder -1 bei Fehler zurück 
    pid = fork();

    //klassische Fallunterscheidung bei fork: Fehler abfangen, im Kindprozess oder im Elternprozess 
    if (pid == -1 ) {
      perror("Fehler bei fork");
    } else if (pid == 0) {
      //im Kindprozess
      printf("Child: Globale Variable = %d, PID = %d\n", global_variable, getpid());
    } else { //alle anderen PIDs
      //im Elternprozess
      printf("Parent: Globale Variable = %d, PID = %d\n", global_variable, getpid());
    }

  }

  return 0;
}
/*
Insgesamt werden 31 Prozesse (+1 Parentprozess) erstellt

Bei unbegrenztem Loop würden wir unbegrenzt viele Prozesse erzeugen ("fork-bomb"), welches das System zum Abstürzen bringen kann.
*/
