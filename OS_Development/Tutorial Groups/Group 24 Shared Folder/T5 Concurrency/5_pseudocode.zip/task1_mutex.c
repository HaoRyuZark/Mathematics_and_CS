struct Mutex {
    sem_t mutex;
};

void mutex_init(struct Mutex *mutex) {
    sem_init(&mutex->mutex, 0, 1); //Mutex unlocked
}

void mutex_lock(struct Mutex *mutex) {
    sem_wait(&mutex->mutex);    //Mutex-- : 1->0
}

void mutex_unlock(struct Mutex *mutex) {
    sem_post(&mutex->mutex);    //Mutex++ : 0->1
}