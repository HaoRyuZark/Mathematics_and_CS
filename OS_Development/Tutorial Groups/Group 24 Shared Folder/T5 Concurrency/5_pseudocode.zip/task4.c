struct barbershop {
    int chairs = 20;
    int waiting;
    sem_t customers;
    sem_t barbers;
    sem_t mutex;
}

void barber_routine(struct barbershop *shop) {
    while (1) {
        //Keinen Kunden -> Barber schläft
        //Wenn doch, dann:
        sem_wait(&shop->customers); // P > 0

        //Kunde kommt rein -> Variable bearbeiten, also Mutex beanspruchen (Variable wird gesperrt)
        sem_wait(&shop->mutex);
        shop->waiting--;
        sem_post(&shop->mutex);

        //Kunde kann frisiert werden
        sem_post(&shop->barbers); // P ++ , also auf 1
        cut_hair(shop);
    }
}

void customer_routine(struct barbershop *shop) {
    sem_wait(&shop->mutex);
    //Schauen, ob noch Warteplätze frei sind, wenn nicht gehen wir
    if (shop->waiting < shop->chairs) {
        //wir setzen uns hin -> Ein Kunde mehr wartet
        shop->waiting++;
        sem_post(&shop->customers); // ein kunde mehr in der warteschlange
        //Warten, bis wir an der reihe sind
        sem_post(&shop->mutex);
        sem_wait(&shop->barbers); // P -- , also auf 0
        get_haircut(shop);

    } else { //wir gehen
        sem_post(&shop->mutex);
    }
}