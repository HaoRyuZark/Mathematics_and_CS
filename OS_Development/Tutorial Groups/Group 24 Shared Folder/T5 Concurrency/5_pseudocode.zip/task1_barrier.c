struct Barrier {
    int n_threads;
    int count;
    sem_t barrier;
    sem_t mutex;
};

// initialize the barrier for later use
void barrier_init(struct Barrier *barrier, int n_threads) {
    barrier->count = 0;
    barrier->n_threads = n_threads;
    sem_init(&barrier->mutex, 0, 1);
    sem_init(&barrier->barrier, 0, 0);
}

// Barrier to ensuite all threads wait here before being released
void barrier_wait(struct Barrier *barrier) {
    //Mutex beanspruchen
    sem_wait(&barrier->mutex);
    barrier->count++;

    if (barrier->count == barrier->n_threads) {
        //Alle Prozesse sind an Barriere angekommen, der erste kann wieder freigegeben werden
        sem_post(&barrier->mutex);
        sem_post(&barrier->barrier);
        return;
    }
    //mutex wieder freigeben, nächste Prozess kann ausgeführt werden
    sem_post(&barrier->mutex);

    sem_wait(&barrier->barrier);
    sem_post(&barrier->barrier);
}