#define KLASSIKER 0
#define VEGETARIAN 1

int studentsAtCounter = 0;
int klassiker = 0;
int vegetarian = 0; // shared variables
Mutex counterLock;
Mutex klassikerLock;
Mutex vegetarianLock;

//mutex_lock(mutex);
//mutex_unlock(mutex);

void fillKlassiker(int n) {
    mutex_lock(&klassikerLock);
    klassiker += n;
    mutex_unlock(&klassikerLock);
}

void fillVegetarian(int n) {
    mutex_lock(&vegetarianLock);
    vegetarian += n;
    mutex_unlock(&vegetarianLock);
}

void arrivalStudent(int wish) {
    mutex_lock(&counterLock);
    studentsAtCounter++;
    if (wish == KLASSIKER) {
        while(1) {
            mutex_lock(&klassikerLock);
            if (klassiker > 0) {
                klassiker--;
                mutex_unlock(&klassikerLock);
                break;
            }
            mutex_unlock(&klassikerLock);
        }
    }
    else if (wish == VEGETARIAN) {
        while(1) {
            mutex_lock(&vegatarianLock);
            if (vegetarian > 0) {
                vegetarian--;
                mutex_unlock(&vegetarianLock);
                break;
            }
            mutex_unlock(&vegetarianLock);
        }
    }
    studentsAtCounter--;
    mutex_unlock(&counterLock);
}