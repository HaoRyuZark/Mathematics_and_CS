#define KLASSIKER 0
#define VEGETARIAN 1

Semaphore klassikerSem(0); // initialize semaphore to 0: no klassiker available at start
Semaphore vegetarianSem(0); // initialize semaphore to 0: no vegetarian available at start
Semaphore counter(1); // initialize semaphore to 1: one place available at the counter

void fillKlassiker(int n) {
    for (int i = 0; i < n; i++) {
        sem_post(&klassikerSem);
    }
}

void fillVegetarian(int n) {
    for (int i = 0; i < n; i++) {
        sem_post(&vegetarianSem);
    }
}

void arrivalStudent(int wish) {
// ensure only 1 student at a time at the counter
    sem_wait(&counter); // Student der jetzt am Schalter ist: Counter= 0
    if (wish == KLASSIKER) {
        sem_wait(&klassikerSem);
    } else if (wish == VEGETARIAN) {
        sem_wait(&vegetarianSem);
    } 
    sem_post(&counter);
}