#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    //Öffne eine Datei "file" mit Read/Write Zugriff
	int fd = open("file", O_RDWR);

    //Fange Fehler ab
	if (fd < 0) {
		perror("open");
		exit(1);
	}

    //lseek ändert den Offset des übergebenen File Deskriptors auf den übergebenen Offset
	int ret = lseek(fd, 5, SEEK_SET);

    //Fehler abfangen
	if (ret == -1) {
		perror("lseek");
		goto out;
	}

	char buf;

	do {
        //Lesen von einem Byte in den Buffer
		ret = read(fd, &buf, 1);
        //Wenn nicht die korrekte Anzahl an Bytes gelesen wurde --> error
		if (ret != 1) {
			goto out;
		}

        //Wenn hier ein a steht, wollen wir es zu b ändern
		if (buf == 'a') {
			buf = 'b';
            
            //Zu schreibende Stelle in file erst überprüfen
			if (lseek(fd, -1, SEEK_CUR) == -1) {
				perror("lseek\n");
				exit(1);
			}
            //b in die Datei schreiben
			ret = write(fd, &buf, 1);
		}
	} while(ret == 1); //solange wir Bytes lesen

    //Schließen des File Deskriptors
out:
	close(fd);
}