#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdlib.h>

int stdout_to_file(char *command, char *args[], char *output_file) {
	// ensure the file is created and truncated when it's opened
	int fd = open(output_file, O_RDWR | O_CREAT | O_TRUNC, 00777);
	pid_t pid;
	int wstatus;

	if (fd < 0) {
		perror("open");
		return -1;
	}

	pid = fork();

	if (pid == 0) { //im Kindprozess

		// dup2 ersetzt stdout File Deskriptor durch unseren fd Deskriptor, 
        // stdout wird also nach output_file umgeleitet
		if (dup2(fd, STDOUT_FILENO) == -1) {
			perror("dup2");
			exit(1);
		}

		// jetzt soll der übergebene command mit den Argumenten ausgeführt werden
        // mit Fehler abfangen
		if (execv(command, args) == -1) {
			perror("execv");
			exit(1);
		}
        //Erinnerung: mit execv wird das Programm des Kindes komplett ersetzt mit command
	}

    // Elternprozess wartet auf Beendigung des Kindes
	if (waitpid(pid, &wstatus, 0) != pid) {
		perror("waitpid");
		close(fd);
		exit(1);
	}

    //File Deskriptor schließen und Kindexitstatus zurückgeben
	close(fd);
	return wstatus;
}

//main-Methode nicht Teil der Aufgabenstellung, dient nur als kleines Beispiel zum Visualisieren
int main() {
    char *command = "/bin/ls";
    char *args[] = { "ls", "-l", NULL };
    char *output_file = "output.txt";

    int status = stdout_to_file(command, args, output_file);

    if (status == 0) {
        printf("Command executed successfully, output is in %s\n", output_file);
    } else {
        printf("Command failed with status %d\n", status);
    }

    return 0;
}