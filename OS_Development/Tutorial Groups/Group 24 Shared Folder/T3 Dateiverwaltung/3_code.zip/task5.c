#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#define BUFFER_SIZE 1024

int cat(char *filenames[], int nr_files) {
	char *filename;
	int fd;
	char buffer[BUFFER_SIZE];
	size_t size;

    // für alle übergebenen Dateien
	for (int i = 0; i < nr_files; i++) {

        // öffnen der Datei an Index i mit Fehler abfangen
		filename = filenames[i];
		fd = open(filename, O_RDONLY);
		if (fd < 0) {
			perror("open");
			continue;
		}

        // Einlesen der Datei und in den stdout schreiben
		size = BUFFER_SIZE;
		while((size = read(fd, buffer, BUFFER_SIZE)) > 0) {
			write(STDOUT_FILENO, buffer, size); // write to stdout (or we could use printf)
		}
        // Fehler bei read abfangen und File Deskriptor schließen
		if (size < 0) {
			perror("read");
		}

		close(fd);
	}
	return 0;
}

//main-Methode nicht Teil der Aufgabenstellung, dient nur als kleines Beispiel zum Visualisieren
//Benutzung mit 2 Dateien, die konkatteniert werden sollen
int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s file1 [file2 ... fileN]\n", argv[0]);
        return 1;
    }
    
    // argv + 1 to skip the program name
    return cat(argv + 1, argc - 1);
}
